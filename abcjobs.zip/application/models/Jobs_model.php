<?php
class Jobs_model extends CI_Model {

    public function __construct()
    {
        
    }

	public function get_jobs($id = FALSE)
	{
	    if ($id === FALSE)
	    {
	        $query = $this->db->get('jobs');
	        return $query->result_array();
	    }

	    $query = $this->db->get_where('jobs', array('id' => $id));
	    return $query->row_array();
	}    

    public function set_jobs()
    {
    	$data = array(
    		'agency_name' => $this->input->post('agency_name'),
    		'agency_address' => $this->input->post('agency_address'),
    		'job_title' => $this->input->post('job_title'),
            'position_available' => $this->input->post('position_available'),
    		'hiring_country' => $this->input->post('hiring_country'),
    		'qualifications' => $this->input->post('qualifications'),
    		'requirements' => $this->input->post('requirements'),
    		'benifits' => $this->input->post('benifits')
    	);

    	$this->db->insert('jobs', $data);
    }

    public function update_jobs()
    {
        $job_id = $this->session->userdata('job_id');
        
        $data = array(
            'agency_name' => $this->input->post('agency_name'),
            'agency_address' => $this->input->post('agency_address'),
            'job_title' => $this->input->post('job_title'),
            'hiring_country' => $this->input->post('hiring_country'),
            'qualifications' => $this->input->post('qualifications'),
            'requirements' => $this->input->post('requirements'),
            'benifits' => $this->input->post('benifits')
        );

        $this->db->where('id', $job_id)->update('jobs', $data);
    }

}