<h3>Student Acceptance</h3>
<ul class="breadcrumb">
  <li><a href="<?php echo site_url('admin/index'); ?>">Admin</a></li>
  <li><a href="<?php echo site_url('students/index/accepted/no'); ?>">Student Applicant</a></li>
  <li>Student Acceptance</li>
</ul>

<h4>You accepted the student for summer job</h4>