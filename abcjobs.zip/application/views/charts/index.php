<h3>Statistics</h3>
<ul class="breadcrumb">
  <li><a href="<?php echo site_url('admin/index'); ?>">Admin</a></li>
  <li>Statistics</li>
</ul>

<h4>Chart of students applied/hired for summer job</h4>
<img src="<?= base_url('images/legend1.png') ?>" ?>&nbsp;Students Applied&nbsp;&nbsp;
<img src="<?= base_url('images/legend2.png') ?>" ?>&nbsp;Students Hired
<br/><br/>
<div style="width: 60%;">
    <canvas id="yearlyChart1" height="150"></canvas>
</div>
<br/><br/>
<h4>Chart of applicants applied/hired for a job</h4>
<img src="<?= base_url('images/legend1.png') ?>" ?>&nbsp;Applicants Applied&nbsp;&nbsp;
<img src="<?= base_url('images/legend2.png') ?>" ?>&nbsp;Applicants Hired
<br/><br/>
<div style="width: 60%;">
    <canvas id="yearlyChart2" height="150"></canvas>
</div>