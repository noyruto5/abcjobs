<h3>Account Deactivated</h3>
<ul class="breadcrumb">
  <li><a href="<?php echo site_url('users/index'); ?>">Admin</a></li>
  <li>Account Deactivated</li>
</ul>


<p class="alert alert-danger">Sorry your account has been deactivated. You cannot login.</p>