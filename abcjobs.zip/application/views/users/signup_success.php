<h3>Sign up success</h3>
<ul class="breadcrumb">
  <li><a href="<?php echo site_url('home'); ?>">Home</a></li>
  <li>Sign up</li>
</ul>

<p class="alert alert-success">Your account is need to be verified by administrator. The system will send you an email after your account has been verified.</p>