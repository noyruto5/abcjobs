<h3>Login success</h3>
<ul class="breadcrumb">
  <li><a href="<?php echo site_url('home'); ?>">Home</a></li>
  <li>Login success</li>
</ul>

<h3>You login was successfull.</h3>