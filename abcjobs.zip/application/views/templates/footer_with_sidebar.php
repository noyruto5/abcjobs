						</div>
					</div>
				</div>
				<!--enc content -->
			<footer class="container-fluid">
				<p>@copyright 2017</p>
			</footer>
			<!-- div container -->
		</div>

			<!-- jQuery library -->

			<!-- Latest compiled JavaScript -->
			<script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>

			<!-- Custom JavaScript -->
			<script src="<?php echo base_url(); ?>js/my-script.js"></script>

			
        </body>
</html>