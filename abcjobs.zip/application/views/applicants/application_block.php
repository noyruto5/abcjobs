<h3><?= $title ?></h3>
<ul class="breadcrumb">
  <li><a href="<?php echo site_url('home'); ?>">Home</a></li>
  <li><?= $title ?></li>
</ul>

<div class="danger col-sm-6 col-sm-offset-6" style="width: 80%;">
  <p>Sorry you cannot apply for a job anymore because you already hired for a job.</p>
</div>