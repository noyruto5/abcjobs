<h3>Applicants Acceptance</h3>
<ul class="breadcrumb">
  <li><a href="<?php echo site_url('admin/index'); ?>">Admin</a></li>
  <li><a href="<?php echo site_url('applicants/index/emp_status/employed'); ?>">Job Applicant</a></li>
  <li>Acceptance</li>
</ul>

<h4>You accepted the applicant for a job.</h4>