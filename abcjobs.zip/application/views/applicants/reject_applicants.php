<h3><?= $title ?></h3>
<ul class="breadcrumb">
  <li><a href="<?php echo site_url('admin/index'); ?>">Admin</a></li>
  <li><a href="<?php echo site_url('applicants/index/emp_status/employed'); ?>">Job Applicant</a></li>
  <li>Acceptance</li>
</ul>

<h4>You rejected an applicantion for a job.</h4>