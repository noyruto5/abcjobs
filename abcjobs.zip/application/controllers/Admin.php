<?php
class Admin extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
	}


	public function index()
	{
		$data['title'] = "Admin Home Page";

		 $this->load->view('templates/header_with_sidebar', $data);
		 $this->load->view('admin/index', $data);
		 $this->load->view('templates/footer');
	}

}