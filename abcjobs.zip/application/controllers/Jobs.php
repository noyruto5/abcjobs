<?php
class Jobs extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('jobs_model');
	}

	public function index()
	{
		$this->auth();

		$data['jobs'] = $this->jobs_model->get_jobs();
		$data['title'] = "Job Hiring";

		 $this->load->view('templates/header_with_sidebar', $data);
		 $this->load->view('jobs/index', $data);
		 $this->load->view('templates/footer_with_sidebar');
	}

	public function view($id = NULL)
    {
    	$this->auth();

        $data['jobs_item'] = $this->jobs_model->get_jobs($id);

        if (empty($data['jobs_item']))
        {
            show_404();
        }

        $data['title'] = $data['jobs_item']['job_title'];

        $this->session->set_userdata('job_id', $data['jobs_item']['id']);

        $this->load->view('templates/header_with_sidebar', $data);
        $this->load->view('jobs/view', $data);
        $this->load->view('templates/footer_with_sidebar');
    }

	public function create()
	{
		$this->auth();

		$data['title'] = "Add Job Hiring";

		$config = array(
			array('field' => 'agency_name', 'label' => 'Agency Name', 'rules' => 'required' ),
			array('field' => 'agency_address', 'label' => 'Agency Address', 'rules' => 'required' ),
			array('field' => 'job_title', 'label' => 'Job Title', 'rules' => 'required' ),
			array('field' => 'hiring_country', 'label' => 'Hiring Country/Places', 'rules' => 'required' )
		);

		$this->form_validation->set_rules($config);

		if ($this->form_validation->run() === FALSE)
        {
            $this->load->view('templates/header_with_sidebar', $data);
		    $this->load->view('jobs/create', $data);
		    $this->load->view('templates/footer_with_sidebar');
        }
        else
        {
            $this->jobs_model->set_jobs();
            redirect('jobs/index');
        }
	}

	public function update()
	{
		
			$this->auth();

			$data['title'] = "Update Job Hiring";

			$config = array(
				array('field' => 'agency_name', 'label' => 'Agency Name', 'rules' => 'required' ),
				array('field' => 'agency_address', 'label' => 'Agency Address', 'rules' => 'required' ),
				array('field' => 'job_title', 'label' => 'Job Title', 'rules' => 'required' ),
				array('field' => 'hiring_country', 'label' => 'Hiring Country/Places', 'rules' => 'required' )
			);

			$this->form_validation->set_rules($config);

			if ($this->form_validation->run() === FALSE)
	        {
	        	$job_id = $this->session->userdata('job_id');
	        	$data['jobs_item'] = $this->jobs_model->get_jobs($job_id);

	            $this->load->view('templates/header_with_sidebar', $data);
			    $this->load->view('jobs/update', $data);
			    $this->load->view('templates/footer_with_sidebar');
	        }
	        else
	        {
	            $this->jobs_model->update_jobs();
	            redirect('jobs/index');
	        }
		
	}

	public function auth()
	{
		if ($this->users_model->authenticate() === FALSE)
        {
            redirect('users/login');
            exit();
        }
	}
}