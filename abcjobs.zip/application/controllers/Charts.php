<?php
class Charts extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		//$this->load->model('charts_model');
	}

	public function index()
	{
		$this->load->view('templates/header_with_sidebar');
		$this->load->view('charts/index');
		$this->load->view('templates/footer_with_sidebar');
	}
}