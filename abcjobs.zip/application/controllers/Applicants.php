<?php
class Applicants extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('applicants_model');
	}

	/* This function must have value for $field_name && $field_value
	*  or else it will return show_404()
	*  the $field_name must correspond to field name of the table in database. and also the value
	*/
	public function index($field_name1 = NULL, $field_value1 = NULL, $field_name2 = NULL, $field_value2 = NULL)
	{
		$this->auth();

		if ($field_name1 !== NULL && $field_value1 !== NULL && $field_name2 !== NULL && $field_value2 !== NULL)
		{
			$data['applicants'] = $this->applicants_model->get_applicants(FALSE, $field_name1, $field_value1, $field_name2, $field_value2);

			$title = ($field_value1 == "any") ? "Hired" : $field_value1;

			$data['title'] = ucfirst($title) . " Applicants";
			$data['field_name1'] = $field_name1;
	        $data['field_value1'] = $field_value1;
	        $data['field_name2'] = $field_name2;
	        $data['field_value2'] = $field_value2;

			$this->load->view('templates/header_with_sidebar', $data);
			$this->load->view('applicants/index', $data);
			$this->load->view('templates/footer_with_sidebar');
		}
		else
		{
			show_404();
		}
		
	}

	/* This function must have value for $applicant_id && $field_name && $field_value
	*  or else it will return show_404()
	*  the $field_name must correspond to field name of the table in database. and also the value
	*/
	public function view($applicant_id = NULL, $field_name1 = NULL, $field_value1 = NULL, $field_name2 = NULL, $field_value2 = NULL)
    {
    	$this->auth();

    	if ($field_name1 !== NULL && $field_value1 !== NULL && $field_name2 !== NULL && $field_value2 !== NULL)
		{
	        $data['applicants_item'] = $this->applicants_model->get_applicants($applicant_id, $field_name1, $field_value1, $field_name2, $field_value2);

	        if (empty($data['applicants_item']))
	        {
	            show_404();
	        }

	        $title = ($field_value1 == "any") ? "Hired" : $field_value1;

	        $data['category'] = ucfirst($title) . " Applicants";
	        $data['title'] = $data['category'] . " | " . $data['applicants_item']['fname'];
	        $data['field_name1'] = $field_name1;
	        $data['field_value1'] = $field_value1;
	        $data['field_name2'] = $field_name2;
	        $data['field_value2'] = $field_value2;

	        $this->session->set_userdata('applicant_id', $data['applicants_item']['applicant_id']);

	        $this->load->view('templates/header_with_sidebar', $data);
	        $this->load->view('applicants/view', $data);
	        $this->load->view('templates/footer_with_sidebar');
	    }
		else
		{
			show_404();
		}
    }

	public function create()
	{
		$this->auth();

		$data['title'] = 'Create Profile';

    	$data['applicants_item'] = $this->applicants_model->was_hired();

    	if ($data['applicants_item']['accepted'] === 'yes')
    	{
    		$data['title'] = "Application Block";
    		$this->load->view('templates/header_with_sidebar', $data);
	        $this->load->view('applicants/application_block');
	        $this->load->view('templates/footer_with_sidebar');
    	}
    	else
    	{
    		$config = array(
				array('field' => 'lname', 'label' => 'Surname', 'rules' => 'required'),
				array('field' => 'fname', 'label' => 'First Name', 'rules' => 'required'),
				array('field' => 'mname', 'label' => 'Last Name', 'rules' => 'required'),
				array('field' => 'bdate', 'label' => 'Birth Date', 'rules' => 'required'),
				array('field' => 'bplace', 'label' => 'Place of Birth', 'rules' => 'required'),
				array('field' => 'sex', 'label' => 'Sex', 'rules' => 'required'),
				array('field' => 'status', 'label' => 'Civil Status', 'rules' => 'required'),
				array('field' => 'citizenship', 'label' => 'Citizenship', 'rules' => 'required'),
				array('field' => 'present_add', 'label' => 'Present Address', 'rules' => 'required'),
				array('field' => 'mobile_no', 'label' => 'Mobile No.', 'rules' => 'required'),
				array('field' => 'employment_status', 'label' => 'Employment Status', 'rules' => 'required')
			);

			$this->form_validation->set_rules($config);

			if ($this->form_validation->run() === FALSE)
	        {
	            $this->load->view('templates/header', $data);
			    $this->load->view('applicants/create', $data);
			    $this->load->view('templates/footer');
	        }
	        else
	        {
	            $this->applicants_model->set_applicant();
	            $this->load->view('templates/header_with_sidebar', $data);
	            $this->load->view('applicants/create_success');
	            $this->load->view('templates/footer_with_sidebar');
	        }
    	}

		
	}

	public function accept_applicants($app_status)
	{
		$this->auth();

		if ($this->applicants_model->update_accept($app_status) === TRUE)
		{
			$data['title'] = 'Applicant Accepted';

			$this->load->view('templates/header_with_sidebar', $data);
            $this->load->view('applicants/accept_applicants');
            $this->load->view('templates/footer_with_sidebar');
		}

	}

	public function reject_applicants($app_status)
	{
		$this->auth();

		if ($this->applicants_model->update_accept($app_status) === TRUE)
		{
			$data['title'] = 'Applicant Rejected';

			$this->load->view('templates/header_with_sidebar', $data);
            $this->load->view('applicants/reject_applicants');
            $this->load->view('templates/footer_with_sidebar');
		}
	}

	public function application_status()
	{
		$data['applicants'] = $this->applicants_model->get_app_status();
		$data['title'] = "Application Status";

	    $this->load->view('templates/header_with_sidebar', $data);
	    $this->load->view('applicants/application_status', $data);
	    $this->load->view('templates/footer_with_sidebar');
	}

	public function auth()
	{
		if ($this->users_model->authenticate() === FALSE)
        {
            redirect('users/login');
            exit();
        }
	}
}